import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

/**
 * The pong agent
 * @author angeloferrando
 *
 */
@SuppressWarnings("serial")
public class ReceiverAgent extends Agent {
	@Override
	protected void setup() {
		super.setup();
		String[] args = (String[]) getArguments();
		String sender = args[0]; // the sender's name
		String content = args[1]; // the message content
		int nSends = Integer.valueOf(args[2]); // number of times the agent sends the message

		addBehaviour(new CyclicBehaviour(this) {

			@Override
			public void action() {
				for(int i = 0; i < nSends; i++){
					ACLMessage msgR = blockingReceive(5000);
					if(msgR != null){
			        	System.out.println("[" + getLocalName() + "]: receive " + msgR.getContent() + " from " + sender); // log
					}
				}

				doWait(5000); // wait 5 sec (just for graphic reasons)
				
				ACLMessage msg = new ACLMessage(ACLMessage.INFORM); // the performative we use
				msg.setSender(getAID()); // set me as sender
				msg.addReceiver(new AID(sender, AID.ISLOCALNAME)); // set alice as receiver
		        msg.setContent(content); // set the content of the message

		        for(int i = 0; i < nSends; i++){
			        System.out.println("[" + getLocalName() + "]: send " + content + " to " + sender); // log
			        send(msg); // send the message
			        doWait(1000); // wait 1 sec (just for graphic reasons)
		        }
			}
		});
	}
}
