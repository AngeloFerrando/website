import java.util.Random;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

/**
 * The sender agent
 * @author angeloferrando
 *
 */
@SuppressWarnings("serial")
public class SenderAgent extends Agent{

	@Override
	protected void setup() {
		super.setup();
		String[] args = (String[]) getArguments();
		String receiver = args[0]; // the receiver's name
		String content = args[1]; // the message content
		int nSends = Integer.valueOf(args[2]); // number of times the agent sends the message

		addBehaviour(new CyclicBehaviour(this) {

			@Override
			public void action() {
				ACLMessage msg = new ACLMessage(ACLMessage.INFORM); // the performative we use
				msg.setSender(getAID()); // set me as sender
				msg.addReceiver(new AID(receiver, AID.ISLOCALNAME)); // set bob as receiver
				msg.setContent(content); // set content of the message

				doWait(5000); // wait 5 sec (just for graphic reasons)

				for(int i = 0; i < nSends; i++){
					System.out.println("[" + getLocalName() + "]: send " + content + " to " + receiver); // log
					send(msg); // send the ping message
					doWait(1000); // wait 1 sec (just for graphic reasons)
				}
				
				for(int i = 0; i < nSends; i++){
					ACLMessage msgR= blockingReceive(); // wait for the pong message
					if(msgR != null) // did I received something?
						System.out.println("[" + getLocalName() + "]: receive " + msgR.getContent() + " from " + receiver); // log
				}
			}
		});
	}

}
